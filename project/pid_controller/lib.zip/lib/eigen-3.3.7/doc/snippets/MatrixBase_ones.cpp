cout << Matrix2d::Ones() << endl;
cout << 6 * RowVector4i::Ones() << endl;
